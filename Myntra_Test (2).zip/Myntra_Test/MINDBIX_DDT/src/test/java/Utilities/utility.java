package Utilities;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;

import baseClass.baseClass;

public class utility extends baseClass
{
	public static boolean presenceOfElement(String targetElement)
	{
		//System.out.println("Inside presenceOfElement utility method");
		
		boolean value = false;
		
		List<WebElement> ele = driver.findElements(By.xpath(targetElement));
				
		if(ele.size()!=0)
		{
			value=true;
			//System.out.println("Element present from utilities");
		}
		
		//System.out.println("Returning control");
		return value;
	}
	
	public static String getText(String element)
	{
		//System.out.println("Inside getText utility method");
		
		String searchedProduct=driver.findElement(By.xpath(element)).getText();
		
		System.out.println(searchedProduct);
		
		searchedProduct=searchedProduct.substring(1, searchedProduct.length()-1);
		
		System.out.println(searchedProduct);
		
		//System.out.println(searchedProduct+" "+"From utilities");
		//System.out.println("Returning control");
		
		return searchedProduct;
	}
	
	public static void takeSS() throws Exception
	{
		Date date = new Date();
		
		String timeStamp = date.toString().replace(" ", "_").replace(":", "_");
		
		File ss = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		
		File errSS = new File(System.getProperty("user.dir")+"\\target"+timeStamp);
		
		FileUtils.copyDirectory(ss, errSS);
	}
}
