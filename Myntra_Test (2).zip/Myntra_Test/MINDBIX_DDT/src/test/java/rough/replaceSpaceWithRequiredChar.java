package rough;

public class replaceSpaceWithRequiredChar {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		String url="https://example.com/ a";
		
		int length = url.length();
		
		int index = url.indexOf(" ");
		
		System.out.println(index);
		
		char a[] = url.toCharArray();
		
		String str = url.split("\\s+")[0];
		
		String str2 = url.split("\\s+")[1];
		
		System.out.println(str2.length());
		
		char c = str2.charAt(0);
		
		String newURL = new StringBuilder().append('%').append("20").append(c).toString();
		
		System.out.println(newURL);
		
		newURL=str+newURL;
		
		System.out.println(newURL);

	}

}
