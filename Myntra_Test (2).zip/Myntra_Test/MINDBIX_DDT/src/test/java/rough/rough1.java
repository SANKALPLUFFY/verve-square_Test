package rough;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class rough1 
{
	public static void main(String a[])
	{
		String generator="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		  
		  String splits[]=generator.split("");
		  
		  Scanner scr = new Scanner(System.in);
		  
		  System.out.println("Enter size");
		  
		  int inputSize=scr.nextInt();
		  
		  Random random = new Random();
		  
		  String randomString="";
		  
		  for(int i=0;i<inputSize;i++)
		  {
			  randomString +=splits[random.nextInt(splits.length)];
		  }
		  
		  System.out.println(randomString);
		  
		  splits = randomString.split("");
		  
		  List<String> repeate = new ArrayList<String>();
		  
		  Map<String,Integer> tbl = new TreeMap<String,Integer>();
		  
		  int n=0;
		  
		  for(int i=0;i<splits.length;i++)
		  {
			  if(tbl.containsKey(splits[i]))
			  {
				  tbl.put(splits[i], tbl.get(splits[i])+1);
			  }
			  else
			  {
				  tbl.put(splits[i], 1);
			  }
			  
			  Set<Map.Entry<String,Integer>> sets = tbl.entrySet();
			  
			  for(Map.Entry<String, Integer> newSets: sets)
			  {
				  if(newSets.getValue()>1&&newSets.getKey().contentEquals(splits[i]))
				  {
					  repeate.add(n, newSets.getKey());
					  
					  n++;
				  }
			  }
		  }
		  
		  System.out.println("First repetative character is:"+" "+" "+repeate.get(0));
	}
}
