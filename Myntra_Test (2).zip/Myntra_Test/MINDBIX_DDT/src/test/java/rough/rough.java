package rough;

import java.util.Hashtable;

import org.testng.annotations.DataProvider;

import excelReader.ExcelReader;

public class rough 
{
	/*@DataProvider(name="testData")
	  public Object[][] dataProvider() throws Exception
	  {
		  ExcelReader reader = new ExcelReader(System.getProperty("user.dir")+"\\src\\test\\resources\\Excels\\New Microsoft Excel Worksheet.xlsx");
		  
		  int rows=reader.getRows(0);
		  
		  int column=reader.getColumns(0, 1);
		  
		  Object[][] data = new Object[rows][1];
		  
		  Hashtable<String,String>excelDetails=null;
		  
		  for(int i=1;i<=rows;i++)
		  {
			  excelDetails=new Hashtable<String,String>();
			  
			  for(int j=0;j<column;j++)
			  {
				  excelDetails.put(reader.excelData(0, 0, j), reader.excelData(0, i, j));
			  }
			  
			  data[i-1][0] = excelDetails;
		  }
		  
		  return data;*/
}
