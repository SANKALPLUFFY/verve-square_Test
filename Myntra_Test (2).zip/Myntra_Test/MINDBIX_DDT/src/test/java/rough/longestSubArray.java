package rough;

public class longestSubArray 
{
	public static void main(String args[])
	{
		int arr1[] = {5, 6, 3, 5, 7, 8, 9, 1, 2};
		
		int length=arr1.length;
		
		findLongestIncreasing(arr1,length);
	}
	
	public static void findLongestIncreasing(int [] arr1,int arr1_len)
	{
	     //Your code goes here.
		
		// need to store max length of array
		// need  to store length of array
		
		
		int maximum=1;
		int maxSub=1;
		int maxstart=0;
		int maxend=0;
		int start=0;
		int end=0;
		int post=0;
		int length=1;
		int num=0;
		
		/*for(int i=1;i<=arr1_len;i++)
		{
			if(arr1[i-1]<arr1[i])
			{
				if(post!=1)
				{
					start=i-1;
					post=1;
				}
				else
				{
					if(i==arr1_len-1)
					{
						end=arr1_len-1;
					}
				}
			}
			else
			{
				if(post==1)
				{
					end=i-1;
					post=0;
				}
			}
			
			if(maxSub<end-start)
			{
				maxSub=end-start;
				maxend=end;
				maxstart=start;
			}
			
			System.out.println(maxSub);
		}*/
		
		for(int i=0;i<arr1.length;i++)
		{
			if(arr1[i-1]>arr1[i])
			{
				length++;
			}
			else
			{
				if(maximum<length)
				{
					maximum=length;
					
					num=i-maximum;
				}
				
				length=1;
			}
		}
		if(maximum<length)
		{
			maximum=length;
			
			num=arr1_len-maximum;
		}
		
		for(int i=maximum;i<num;i++)
		{
			System.out.println(arr1[i]);
		}
	}

}
