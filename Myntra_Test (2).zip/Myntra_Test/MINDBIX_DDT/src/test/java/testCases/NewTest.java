package testCases;


import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import Utilities.utility;
import baseClass.baseClass;
import excelReader.ExcelReader;
import pageFactory.amazonHomepageElements;
import pageFactory.myntraElements;

public class NewTest extends baseClass 
{
	
  @Test()
  public void myntra() throws Exception 
  {
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	myntraElements obj = new myntraElements(driver);
	
	WebDriverWait wait;
	
	Actions action;
	
	//--------------------------------------------------------STEP 1-- verifying landing page
	
	if(obj.homepageLogo.isDisplayed())
	{
		System.out.println("Correct landing page");
	}
	else
	{
		Assert.assertTrue(true, "Incorrect landing page");
	}
	
	//---------------------------------------------------------Step 2-- Men's tab
	
	if(obj.men_sTab.isDisplayed())
	{
		action = new Actions(driver);
		
		action.moveToElement(obj.men_sTab).perform();;
		
		Thread.sleep(1500);
		
		wait = new WebDriverWait(driver,20);
		
		wait.until(ExpectedConditions.visibilityOf(obj.Phone_Cases));
		
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//-------------------------------------------------------Step 3-- Selecting phone cases option
		
		if(obj.Phone_Cases.isDisplayed())
		{
			obj.Phone_Cases.click();
			
			//Thread.sleep(1500);
		}
		else
		{
			Assert.assertTrue(true, "Phone Cases option is not available");
		}
	}
	else
	{
		Assert.assertTrue(true, "Men's tab is not available");
	}
	
	//-------------------------------------------------------------Step 4-- Selecting 3rd row 3rd element from search reasult
	
	((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", obj.third_rd_Row_Element);
	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	obj.third_rd_Row_Element.click();
	
	Thread.sleep(1500);
	
	//-------------------------------------------------------------Step 5-- Verify price is displayed and price should not less than Rs. 10
	
	List<String> tabs = new ArrayList<String>(driver.getWindowHandles());
	
	driver.switchTo().window(tabs.get(1));
	
	Thread.sleep(3000);
	
	String name = obj.coverPrice.getText();
	
	//System.out.println(name);
	
	name=name.split(". ")[1];
	
	
	int currentPrice=Integer.parseInt(name);
	
	if(currentPrice<=10)
	{
		Assert.assertTrue(true, "Incorrect price");
	}
	else
	{
		System.out.println("Price is correct");
	}
	
	//---------------------------------------------------------------Step 6-- Verify  ADD TO BAG button is displayed
	
	List<WebElement> ele = driver.findElements(By.xpath(obj.addToBagButton_XPATH));
	
	if(ele.size()!=0)
	{
		System.out.println("ADD TO BAG button is present on the page");
	}
	else
	{
		Assert.assertTrue(true, "ADD TO BAG button is not present on the page");
	}
	
  }
  
  
  }
  

