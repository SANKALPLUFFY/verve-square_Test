package pageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class myntraElements 
{
	@FindBy(xpath="//*[@data-reactid='16']") public static WebElement homepageLogo;
	
	@FindBy(xpath="//*[@data-reactid='19']") public static WebElement men_sTab;
	
	@FindBy(xpath="//a[@href='/mobile-phone-cases']") public static WebElement Phone_Cases;
	
	@FindBy(xpath="//*[@title='TREEMODA Grey Solid iPhone 11 Case']") public static WebElement third_rd_Row_Element;
	
	@FindBy(xpath="//*[@id=\"mountRoot\"]/div/div/div/main/div[2]/div[2]/div[1]/p[1]/span[1]/strong") public static WebElement coverPrice;
	
	@FindBy(xpath="//*[contains(text(),'ADD TO BAG')]") public static  WebElement addToBagButton;
	
	public static String addToBagButton_XPATH = "//*[contains(text(),'ADD TO BAG')]";
	
	
	
	WebDriver driver;
	
	
	public myntraElements(WebDriver driver)
	{
		this.driver=driver;
		
		PageFactory.initElements(driver, this);
	}
}
