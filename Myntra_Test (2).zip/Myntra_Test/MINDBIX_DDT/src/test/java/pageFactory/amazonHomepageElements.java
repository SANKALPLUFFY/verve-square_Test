package pageFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import baseClass.baseClass;

public class amazonHomepageElements extends baseClass
{
	@FindBy(id="twotabsearchtextbox") private static WebElement searchBox;
	
	public String productName=OR.getProperty("searchedProduct_XPATH");
	
	@FindBy(xpath="//*[@id=\"search\"]/span/div/span/h1/div/div[1]/div/div/span[3]") private WebElement productSearched;
	
	
	WebDriver driver;
	
	Actions action;
	WebDriverWait wait; 
	
	public void search(String product)
	{
		
		searchBox.click();
		
		searchBox.sendKeys(product);
		
		action = new Actions(driver);
		
		action.sendKeys(Keys.ENTER).perform();	
		
		wait = new WebDriverWait(driver,20);
		
		wait.until(ExpectedConditions.visibilityOf(productSearched));
		
		System.out.println("product found");
	}
	
	public void clear(String product)
	{
		int len = product.length();
		
		searchBox.click();
		
		for(int i=0;i<len;i++)
		{
			searchBox.clear();
		}
	}
	
	
	public amazonHomepageElements(WebDriver driver)
	{
		this.driver=driver;
		
		PageFactory.initElements(driver, this);
	}
}
