package baseClass;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class baseClass 
{
	public static Properties OR = new Properties();
	public static  WebDriver driver;
	public static FileInputStream Properties_File;
	public static String excelPath;
	
	@BeforeSuite
	public void startUp() throws Exception
	{
		if(driver==null)
		{
			try {
				Properties_File = new FileInputStream(System.getProperty("user.dir") + "\\src\\test\\resources\\"
						+ "Properties\\OR.properties");
				
				OR.load(Properties_File);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			
			if(OR.getProperty("browser").equalsIgnoreCase("chrome"))
			{
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\src\\test\\resources\\drivers\\chromedriver.exe");
				
				System.setProperty("webdriver.chrome.logfile", System.getProperty("user.dir")+"\\target\\SeleniumLogs.txt");
				
				// Create object of HashMap Class
				Map<String, Object> prefs = new HashMap<String, Object>();
		              
		                // Set the notification setting it will override the default setting
				prefs.put("profile.default_content_setting_values.notifications", 2);
		 
		                // Create object of ChromeOption class
				ChromeOptions options = new ChromeOptions();
		 
		                // Set the experimental option
				options.setExperimentalOption("prefs", prefs);
				
				        // Disable the notification bar
				options.setExperimentalOption("useAutomationExtension", false);
				
				options.setExperimentalOption("excludeSwitches",Collections.singletonList("enable-automation"));  
		                // pass the options object in Chrome driver

				driver = new ChromeDriver(options);	
				
				//System.out.println("Excel path is: "+" "+OR.getProperty("excelPath"));
				
				driver.get(OR.getProperty("testURL"));
				
				driver.manage().deleteAllCookies();
				
				driver.manage().window().maximize();
				
				driver.manage().timeouts().implicitlyWait((Integer.parseInt(OR.getProperty("implicit.wait"))), TimeUnit.SECONDS);
			}
		}
		
	}
	
	@AfterSuite
	public void closing()
	{
		if(driver!=null)
		{
			driver.quit();
		}
	}
	
}
