package excelReader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader 
{
	XSSFWorkbook wb;
	
	public   ExcelReader(String excelPath) throws Exception
	{
			try {
				File excel = new File(excelPath);
				
				FileInputStream readExcel = new FileInputStream(excel);
				
				wb = new XSSFWorkbook(readExcel);
			}  catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	public int getRows(int sheetID)
	{
		int totalRows=wb.getSheetAt(sheetID).getLastRowNum();
		
		return totalRows;
	}
	
	public  int getColumns(int sheetID,int row)
	{
		int totalColumns=wb.getSheetAt(sheetID).getRow(row).getLastCellNum();
		
		return totalColumns;
	}
	
	public String excelData(int sheetID,int row,int column)
	{
		XSSFSheet sheet = wb.getSheetAt(sheetID);
		
		String excelData = sheet.getRow(row).getCell(column).toString();
		
		return excelData;
	}
}
